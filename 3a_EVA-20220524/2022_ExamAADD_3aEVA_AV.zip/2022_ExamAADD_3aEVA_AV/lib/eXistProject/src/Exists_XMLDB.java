
import static EmpleYDepart.PruebasEmpleYDepart.conectar;
import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xmldb.api.*;
import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mrnovoa
 */
public class Exists_XMLDB {
    
    static Scanner teclado = new Scanner(System.in);
    static String driver = "org.exist.xmldb.DatabaseImpl"; //Driver para eXist
    //static String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/Pruebas/ColeccionPruebas"; //URI colecci�n   
    static String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/ColeccionPruebas"; //URI colecci�n   
    static String usu = "admin"; //Usuario
    static String usuPwd = ""; //Clave
    static Collection col = null;
    
     public static Collection conectar() throws NoSuchMethodException, InstantiationException {

        try {
            Class cl = Class.forName(driver); //Cargar del driver 
            //Database database = (Database) cl.getDeclaredConstructors().newInstance(); //Instancia de la BD         
            //Database database = (Database) cl.newInstance(); // Instanciamos la BD (depricated) 
            Database database;
            try {
                database = (Database) cl.getDeclaredConstructor().newInstance();
                DatabaseManager.registerDatabase(database); //Registro del driver
            col = DatabaseManager.getCollection(URI, usu, usuPwd);
            return col;
            } catch (IllegalAccessException ex) {
                Logger.getLogger(Exists_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalArgumentException ex) {
                Logger.getLogger(Exists_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvocationTargetException ex) {
                Logger.getLogger(Exists_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
            }
           
        } catch (XMLDBException e) {
            System.out.println("Error al inicializar la BD eXist.");
            //e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("Error en el driver.");
            //e.printStackTrace();
        }catch (InstantiationException e) {
            System.out.println("Error al instanciar la BD.");
            //e.printStackTrace();
        }
        //e.printStackTrace();
        return null;
    }
     
    public static void ejecucionConsulta(String consultaXQuery, String mensaje) throws XMLDBException{
        XPathQueryService servicio,servicio2;
                servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
                
                ResourceSet result = servicio.query(consultaXQuery);
                
                //ResourceSet result2 = servicio2.query(consultaXQueryCount);
                
                // recorrer los datos del recurso.  
                ResourceIterator i;
                i = result.getIterator();
                if (!i.hasMoreResources()) {
                    System.out.println(" LA CONSULTA NO DEVUELVE NADA O EST� MAL ESCRITA");
                }
                
                System.out.println("******"+mensaje+"*******");
                System.out.println("******XQuery*******\n");
                while (i.hasMoreResources()) {
                    Resource r = i.nextResource();
                    //System.out.println("--------------------------------------------");
                    
                    System.out.println((String) r.getContent());
                }
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) throws NoSuchMethodException, InstantiationException {
        if (conectar() != null) {
            try {
//                String consultaXPath = "/bib/libro/titulo";
//                String expresion = "count(/bib/libro )";
                String consultaXQuery = "for $libro in collection('/db/apps/collection')/bib/libro return $libro/titulo";
                
                String consultaXQueryCount = "for $libro in collection('/db/apps/collection')/bib/libro let $tit := $libro/titulo return <libros>{data($libro/titulo)} <uds>{count($tit)}</uds></libros>";
                        //"for $libro in collection('/db/apps/collection')/bib/libro return count($libro )";
                
                ejecucionConsulta(consultaXQuery,"Listado Libros");
                System.out.println("--------------------------------------------");
              
                ejecucionConsulta(consultaXQueryCount,"Número de libros. Cantidad");
   
                col.close();
            } catch (XMLDBException e) {
                System.out.println(" ERROR AL CONSULTAR DOCUMENTO.");
                e.printStackTrace();
            }
        } else {
            System.out.println("Error en la conexion. Comprueba datos.");
        }
    }

}
