
import java.util.Scanner;
import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQPreparedExpression;
import javax.xml.xquery.XQResultSequence;
import net.xqj.exist.ExistXQDataSource;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mrnovoa
 */
public class Exists_XQJ {

    private XQConnection createConnection() {

        XQConnection conexion = null;
        try {
            XQDataSource recurso = new ExistXQDataSource();
            recurso.setProperty("serverName", "localhost");
            recurso.setProperty("port", "8080");
 
            //Configurados puerto y servidor , creamos conexi�n.
            conexion = recurso.getConnection("admin", "");
        } catch (XQException e) {
            e.printStackTrace();
        }
        return conexion;
    }
    
    public static void ejecutarConsultaXPath(XQPreparedExpression query,String Consulta, String mensaje) throws XQException{
        XQResultSequence result = query.executeQuery();
        System.out.println("******"+mensaje+"*******");

        System.out.println("******XPath*******\n");
        while (result.next()) {
            System.out.println(result.getItemAsString(null));
        }
    }
    
    public static void ejecutarConsultaXQuery(XQExpression query,String consultaXQuery, String mensaje) throws XQException{
        XQResultSequence result = query.executeQuery(consultaXQuery);
        System.out.println("******"+mensaje+"*******");

        System.out.println("******XQuery*******\n");
        while (result.next()) {
            System.out.println(result.getItemAsString(null));
        }
          
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        
        Exists_XQJ exist = new Exists_XQJ();
        XQConnection connection = exist.createConnection();

        if (connection == null) {
            throw new IllegalArgumentException("Fallo al conectar con eXist. Los datos de conexión no son válidos");
        }

        String consultaXQuery = "for $libro in collection('/db/apps/collection')/bib/libro return $libro/titulo";
        //String consultaXPath = "/bib/libro/titulo";
        String consultaXPathCollection = "collection('/db/apps/collection')/bib/libro/titulo";
        
        String expresionCollectionCount = " count(collection('/db/apps/collection')/bib/libro )";
        //String expresion = "count(/bib/libro )";
        
        try {
            XQExpression query = connection.createExpression();
            //XQResultSequence result1 = query.executeQuery(consultaXQuery);
            ejecutarConsultaXQuery(query,consultaXQuery,"Libros");
           
            XQPreparedExpression consulta2 = connection.prepareExpression(consultaXPathCollection);
            //XQResultSequence result2 = consulta2.executeQuery();
            ejecutarConsultaXPath(consulta2,consultaXPathCollection,"Libros");
            
            XQPreparedExpression consulta3 = connection.prepareExpression(expresionCollectionCount);  
            //XQResultSequence result3 = consulta3.executeQuery();
            ejecutarConsultaXPath(consulta3,expresionCollectionCount,"Num Libros");

            connection.close();
        } catch (XQException e) {
            e.printStackTrace();
        }
    }

}
