
import java.util.Scanner;
import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQResultSequence;
import net.xqj.exist.ExistXQDataSource;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mrnovoa
 */
public class Exists_old {

    private XQConnection createConnection() {

        XQConnection conexion = null;
        try {
            XQDataSource recurso = new ExistXQDataSource();
            recurso.setProperty("serverName", "localhost");
            recurso.setProperty("port", "8080");
  

            //Configurados puerto y servidor , creamos conexi�n.
            conexion = recurso.getConnection("admin", "");
        } catch (XQException e) {
            e.printStackTrace();
        }
        return conexion;
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        
        Exists_old exist = new Exists_old();
        XQConnection connection = exist.createConnection();

        if (connection == null) {
            throw new IllegalArgumentException("Fallo al conectar con eXist. Los datos de conexión no son válidos");
        }

        String consulta = "for $libro in /biblioteca/libro return $libro/titulo";

        try {
            XQExpression query = connection.createExpression();
            XQResultSequence result = query.executeQuery(consulta);

            System.out.println("******LIBROS*******\n");

            while (result.next()) {
                System.out.println(result.getItemAsString(null));
            }

        } catch (XQException e) {
            e.printStackTrace();
        }
    }

}
