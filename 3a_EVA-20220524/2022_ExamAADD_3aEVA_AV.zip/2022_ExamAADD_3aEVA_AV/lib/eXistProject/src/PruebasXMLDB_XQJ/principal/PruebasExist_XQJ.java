package PruebasXMLDB_XQJ.principal;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;

import java.io.FileWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;



import javax.xml.xquery.XQException;
import javax.xml.xquery.XQPreparedExpression;

import javax.xml.xquery.XQResultSequence;
import net.xqj.exist.ExistXQDataSource;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.xml.parsers.*;

import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQResultItem;
import javax.xml.xquery.XQSequence;


public class PruebasExist_XQJ {


    public static void main(String[] args) throws IOException, ParserConfigurationException, XQException {
        verproductos();//Ver to2 productos
//        cuentaproduc();//"Numero de productos con precio > de 50: "
        numporzona();//"Numero de productos por cada zona "
//        ejecutarconsultadefichero();//miconsulta.xq(: Productos con precio > 50 y zona 10 :)
//        creaemple10();//NUEVO_EMPLE10.xml
        
//        empDep10() ;
//        muestraDatosProductosXML();
    }

    public static void verproductos() {
        try {
            XQDataSource server = new ExistXQDataSource();
            server.setProperty("serverName", "localhost");
            server.setProperty("port", "8080");
            server.setProperty("user", "admin");
            //server.setProperty("password", "admin");
            server.setProperty("password", "");
            XQConnection conn = server.getConnection();

            XQPreparedExpression consulta;
            XQResultSequence resultado;
            System.out.println("------- Consulta documentos productos.xml ------");
            consulta = conn
                            //.prepareExpression("for $de in collection('/db/Pruebas/BDProductosXML')/productos/produc return $de");
                .prepareExpression("for $de in collection('/db/ColeccionesXML/BDProductosXML')/productos/produc return $de");
            resultado = consulta.executeQuery();
            while (resultado.next()) {
                    System.out.println("Elemento getItem " + resultado.getSequenceAsString(null));

            }
            conn.close();
        } catch (XQException ex) {
            System.out.println("Error en las propiedades del server.");
            System.out.println("Error al operar.");
            ex.printStackTrace();
        }
}

public static void cuentaproduc() {
    try {
        XQDataSource server = new ExistXQDataSource();
        server.setProperty("serverName", "localhost");
        server.setProperty("port", "8080");
        server.setProperty("user", "admin");
        server.setProperty("password", "");
        XQConnection conn = server.getConnection();
        XQPreparedExpression consulta = conn
                        .prepareExpression(" count(collection('/db/ColeccionesXML/BDProductosXML')/productos/produc[precio>50] )");
        XQResultSequence resultado = consulta.executeQuery();
        resultado.next();
        System.out.println("--------------------------------------------");
        System.out.println("N�mero de productos con precio > de 50: " + resultado.getInt());
        conn.close();
    } catch (XQException ex) {
            System.out.println("Error en las propiedades del server.");
            System.out.println("Error al operar.");
            Logger.getLogger(PruebasExist_XQJ.class.getName()).log(Level.SEVERE, null, ex);
    }
}

public static void ejecutarconsultadefichero() {
    try {
        XQDataSource server = new ExistXQDataSource();
        server.setProperty("serverName", "localhost");
        server.setProperty("port", "8080");
        server.setProperty("user", "admin");
        server.setProperty("password", "");
        XQConnection conn = server.getConnection();
        InputStream query;
        query = new FileInputStream("miconsulta.xq");
        XQExpression xqe = conn.createExpression();

        XQSequence resultado = xqe.executeQuery(query);
        System.out.println("----- Consulta desde fichero -------");
        while (resultado.next()) {
                //System.out.println(resultado.getItem().toString());
                System.out.println(resultado.getItem().getItemAsString(null));
        }
        conn.close();
    } catch (XQException ex) {
        System.out.println("Error en las propiedades del server.");
        System.out.println("Error al operar.");
        Logger.getLogger(PruebasExist_XQJ.class.getName()).log(Level.SEVERE, null, ex);
    } catch (FileNotFoundException ex) {
        Logger.getLogger(PruebasExist_XQJ.class.getName()).log(Level.SEVERE, null, ex);
    }
}

    @SuppressWarnings("empty-statement")
    public static void creaemple10() {
            String nom_archivo = "NUEVO_EMPLE10.xml";
            File fichero = new File(nom_archivo);

            XQDataSource server = new ExistXQDataSource();
            try {
                    server.setProperty("serverName", "localhost");
                    server.setProperty("port", "8080");
                    XQConnection conn = server.getConnection();
                    XQPreparedExpression consulta = conn
                                    .prepareExpression("let $titulo:= collection('/db/ColeccionesXML/ColeccionPruebas')/EMPLEADOS/TITULO  "
                                                    + " return  <EMPLEADOS>{$titulo} " + " {for $em in collection('/db/ColeccionesXML/ColeccionPruebas')"
                                                    + "/EMPLEADOS/EMP_ROW[DEPT_NO=10] return $em} " + " </EMPLEADOS> ");
                    XQResultSequence result = consulta.executeQuery();
                    if (fichero.exists()) { // borramos el archivo si existe y se crea
                                                                    // de nuevo
                            if (fichero.delete())
                                    System.out.println("Archivo borrado. Creo de nuevo.");
                            else
                                    System.out.println("Error al borrar el archivo");
                    }
                    try {
                            BufferedWriter bw = new BufferedWriter(new FileWriter(nom_archivo));
                            bw.write("<?xml version='1.0' encoding='ISO-8859-1'?>" + "\n");
                            result.next();
                            //String cad = result.toString();
                            String cad = result.getItem().getItemAsString(null);
                            //System.out.println(result.getItem().getItemAsString(null));
                            System.out.println(" output " + cad); // visualizamos
                            bw.write(cad + "\n"); // grabamos en el fichero
                            bw.close(); // Cerramos el fichero el fichero
                    } catch (IOException ioe) {
                            ioe.printStackTrace();
                    }
                    conn.close();
            } catch (XQException e) {
                    e.printStackTrace();
            }

    }

    public static void numporzona() {
        try {
            XQDataSource server = new ExistXQDataSource();
            server.setProperty("serverName", "localhost");
            server.setProperty("port", "8080");
            server.setProperty("user", "admin");
            server.setProperty("password", "");
            XQConnection conn = server.getConnection();
            XQPreparedExpression consulta = conn
                            .prepareExpression(" for $zo in collection('/db/ColeccionesXML/BDProductosXML')/zonas/zona "
                                            + "let $cu:= count(collection('/db/ColeccionesXML/BDProductosXML')/"
                                            + "productos/produc[cod_zona=$zo/cod_zona]) "
                                            + " return  concat($zo/nombre,', productos: ', $cu) ");
            XQResultSequence resultado = consulta.executeQuery();
            System.out.println("-------------------------------------");
            System.out.println("N�mero de productos por cada zona ");
            while (resultado.next()) {
                    System.out.println(resultado.getSequenceAsString(null));
            }
            conn.close();
        } catch (XQException ex) {
            System.out.println("Error en las propiedades del server.");
            System.out.println("Error al operar.");
            Logger.getLogger(PruebasExist_XQJ.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Ver empleados del dpto 10
    public static void empDep10() throws XQException{
        //preparamos la conexion
        XQDataSource server = new ExistXQDataSource(); 
        server.setProperty("serverName", "localhost"); 
        server.setProperty("port", "8080"); 
        server.setProperty("user", "admin");
        server.setProperty("password", "");
        XQConnection conexion = server.getConnection();
        //preparamos la consulta
        XQPreparedExpression consulta;
        XQResultSequence resultado = null;
        
        consulta = conexion.prepareExpression("/EMPLEADOS/EMP_ROW[DEPT_NO = 10]");
        //ejecutamos la consulta 
        resultado = consulta.executeQuery();
        
        //recorremos el resultado para visualizarlo
        while(resultado.next()){
            System.out.println("Elemento: " +resultado.getItemAsString(null));       
        }
        
        // recuperamos los resultados con XQResultItem
        XQResultItem resItem; 
        while(resultado.next()){
            resItem = (XQResultItem) resultado.getItem();
            System.out.println("Elemento: " +resItem.getItemAsString(null));
        }
        
        
        conexion.close();
    }

    //Mostrar los datos del documento productos.xml, si tenemos productos en distintos documentos se mostrarán las etiquetas de todos los documentos:
    public static void muestraDatosProductosXML() throws XQException{
        //preparamos la conexion
        XQDataSource server = new ExistXQDataSource(); 
        server.setProperty("serverName", "localhost"); 
        server.setProperty("port", "8080"); 
        server.setProperty("user", "admin");
        server.setProperty("password", "");
        XQConnection conexion = server.getConnection();
        System.out.println("------- Consulta documentos productos.xml -------");
        //preparamos la consulta
        XQPreparedExpression consulta; XQResultSequence resultado; // conulta en xquery
        consulta = conexion.prepareExpression("for $pro in /productos return $pro");
        //ejecutamos la consulta 
        resultado = consulta.executeQuery(); 
        //recuperamos los resultados 
        while(resultado.next()){ 
            System.out.println("Elemento: " +resultado.getItemAsString(null));
        }
    }
}
