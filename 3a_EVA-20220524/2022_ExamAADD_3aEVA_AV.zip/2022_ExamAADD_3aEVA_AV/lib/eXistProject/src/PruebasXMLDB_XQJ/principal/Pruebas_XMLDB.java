package PruebasXMLDB_XQJ.principal;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Node;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Database;

import org.xmldb.api.base.XMLDBException;

import org.xmldb.api.modules.XMLResource;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.ResourceIterator;
import org.xmldb.api.base.ResourceSet;

import org.xmldb.api.modules.CollectionManagementService;

import org.xmldb.api.modules.XPathQueryService;

public class Pruebas_XMLDB {

    public static void main(String[] args) throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, InvocationTargetException, InvocationTargetException, InvocationTargetException {
        try {
                //Actividad 5.4. pág 309-310
                bajardocumento();//crea zonas.xml
        } catch (TransformerConfigurationException e) {

                e.printStackTrace();
        } catch (TransformerException e) {

                e.printStackTrace();
        }

        try {   //página 306
            //El siguiente ejemplo realiza una conexión con la BD 
            //para acceder al documento empleados.xml y obtener los empleados del departamento 10.
            verempleados10();

            //Para crear una nueva colección, se llama al método createCollection() del servicio CollectionManagementService.
            //crearcoleccysubirarchivo("/ColeccionesXML/ColeccionPruebas");
            //borra el documento anterior de la colección, comprobando si existe. Se utiliza el método removeResource().
            //borrarfichero("/ColeccionesXML/ColeccionPruebas","NUEVAS_ZONAS.xml");
        } catch (XMLDBException e) {
                // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            //
            vercolecciones();
        } catch (InvocationTargetException ex) {
            Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            //pág 307
            verrecursosdelascolecciones();
        } catch (InvocationTargetException ex) {
            Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    //                prueba1();
//            try {
//                prueba2();
//            } catch (TransformerException ex) {
//                Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
//            }
        // actualizaproductos();
        //borrarcoleccion("Pruebas");
//        borrarfichero("Pruebas","departamentos.xml");
         
        ejecutarconsultafichero("miconsulta.xq");
    }

    /*
* realizar una conexión a la base de datos para acceder al documento empleados.xl 
    y * obtener los empleados del departamento 10 - Ejemplo01ListaEmpleados
*/
    public static void verempleados10() throws XMLDBException {
            String driver = "org.exist.xmldb.DatabaseImpl"; // Driver para eXist
            Collection col = null; // Coleccion
            String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/ColeccionPruebas";
            String usu = "admin"; // Usuario
            String usuPwd = ""; // Clave
            try {
                    Class cl = Class.forName(driver);// cargar el driver
                    Database database = (Database) cl.getDeclaredConstructor().newInstance();// Instanciamos la BD
                    DatabaseManager.registerDatabase(database);// registro de la BD

                    // si no ha habido errores abrimos la coleccion
                    col = DatabaseManager.getCollection(URI, usu, usuPwd);
                    if (col == null)
                            System.out.println(" *** LA COLECCION NO EXISTE. ***");
                   
                    /*// comprobar si un documento existe
                    XMLResource res = null; 
                    res = (XMLResource) coleccion.getResource("empleados.xml"); 
                    if(res == null){
                    System.out.println("EL FICHERO NO EXISTE");
                    }*/
                    
                    XPathQueryService servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
                    
                    // creamos la consulta
//                    String xpath = "for $emp in /EMPLEADOS/EMP_ROW[DEPT_NO = 10] return $emp";
//                    ResourceSet resultado = servicio.query(xpath);

                    ResourceSet result = servicio.query("for $em in /EMPLEADOS/EMP_ROW[DEPT_NO=10] return $em");
                    
                    // Recorrer los datos del recurso.
                    ResourceIterator i;
                    i = result.getIterator();
                    if (!i.hasMoreResources())
                            System.out.println(" LA CONSULTA NO DEVUELVE NADA.");
                    while (i.hasMoreResources()) {
                            Resource r = i.nextResource();
                            System.out.println((String) r.getContent());
                    }
                    col.close(); // borramos
            } catch (Exception e) {
                    System.out.println("Error al inicializar la BD eXist");
                    e.printStackTrace();
            }
    }// FIN verempleados10

    public static void bajardocumento() throws TransformerConfigurationException, TransformerException, NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
            // Localizar un documento, extraerlo y guardarlo en disco
            String driver = "org.exist.xmldb.DatabaseImpl"; // Driver para eXist
            try {
                    Class cl = Class.forName(driver); // Cargar del driver
                    Database database = (Database) cl.getDeclaredConstructor().newInstance(); // Instancia de la
                                                                                                                            // BD
                    DatabaseManager.registerDatabase(database); // Registro del driver
                    String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/BDProductosXML";
                    String usu = "admin"; // Usuario
                    String usuPwd = ""; // Clave
                    Collection col = DatabaseManager.getCollection(URI, usu, usuPwd);
                    XMLResource res = (XMLResource) col.getResource("zonas.xml");
                    if (res == null) {
                            System.out.println("NO EXISTE EL DOCUMENTO");
                    } else {
                            System.out.println("ID del documento: " + res.getDocumentId());
                            // Volcado del documento a un �rbol DOM
                            Node document = (Node) res.getContentAsDOM();
                            Source source = new DOMSource(document);
                            // Volcado del documento de memoria a consola
                            Transformer transformer = TransformerFactory.newInstance().newTransformer();
                            Result console = new StreamResult(System.out);
                            transformer.transform(source, console);
                            // Volcado del documento a un fichero
                            Result fichero = new StreamResult(new java.io.File("./zonas.xml"));
                            transformer = TransformerFactory.newInstance().newTransformer();
                            transformer.transform(source, fichero);
                    }
            } catch (ClassNotFoundException ex) {
                    System.out.println(" ERROR EN EL DRIVER. COMPRUEBA CONECTORES.");
            } catch (InstantiationException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (IllegalAccessException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (XMLDBException ex) {
                    ex.printStackTrace();
            }
    }

    public static void vercolecciones() throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
            String driver = "org.exist.xmldb.DatabaseImpl";
            try {
                    Class cl = Class.forName(driver);
                    Database database = (Database) cl.getDeclaredConstructor().newInstance();
                    DatabaseManager.registerDatabase(database);
                    String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/";
                    String usu = "admin";
                    String usuPwd = "";
                    Collection col = DatabaseManager.getCollection(URI, usu, usuPwd);
                    System.out.println("N�mero de colecciones: " + col.getChildCollectionCount());
                    String[] colecciones = col.listChildCollections();
                    for (int j = 0; j < colecciones.length; j++) {
                            System.out.println(colecciones[j]);
                            // Collection colecc = col.getChildCollection(colecciones[j]);
                    }
            } catch (ClassNotFoundException ex) {
                    System.out.println(" ERROR EN EL DRIVER. COMPRUEBA CONECTORES.");
            } catch (IllegalAccessException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (XMLDBException ex) {
                    Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InstantiationException ex) {
                    Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    public static void verrecursosdelascolecciones() throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
            String driver = "org.exist.xmldb.DatabaseImpl";
            try {
                    Class cl = Class.forName(driver);
                    Database database = (Database) cl.getDeclaredConstructor().newInstance();
                    DatabaseManager.registerDatabase(database);
                    String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML";
                    String usu = "admin";
                    String usuPwd = "";
                    Collection col = DatabaseManager.getCollection(URI, usu, usuPwd);
                    System.out.println("N�mero de colecciones: " + col.getChildCollectionCount());
                    String[] colecciones = col.listChildCollections();
                    for (int j = 0; j < colecciones.length; j++) {
                            System.out.println("-------------------------- ");
                            System.out.println(colecciones[j]);
                            Collection colecc = col.getChildCollection(colecciones[j]);
                            String[] lista = colecc.listResources();
                            for (int i = 0; i < lista.length; i++) {
                                    Resource res = (Resource) colecc.getResource(lista[i]);
                                    System.out.println("ID del documento: " + res.getId());
                                    System.out.println("Contenido del documento:\n " + res.getContent());
                            }
                    }
            } catch (ClassNotFoundException ex) {
                    System.out.println(" ERROR EN EL DRIVER. COMPRUEBA CONECTORES.");
            } catch (IllegalAccessException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (XMLDBException ex) {
                    ex.printStackTrace();
            } catch (InstantiationException ex) {
                    ex.printStackTrace();
            }
    }

    public static void prueba1() throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalAccessException, IllegalArgumentException, IllegalArgumentException, InvocationTargetException, IllegalArgumentException {
            String driver = "org.exist.xmldb.DatabaseImpl"; // Driver para eXist
            try {
                    Class cl = Class.forName(driver); // Cargar del driver
                    Database database = null;
                try {
                    database = (Database) cl.getDeclaredConstructor().newInstance(); // Instancia de la
                } catch (IllegalArgumentException ex) {
                    Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InvocationTargetException ex) {
                    Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
                }
                                                                                              // BD
                    DatabaseManager.registerDatabase(database); // Registro del driver

                    String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/BDProductosXML";
                    String usu = "admin"; // Usuario
                    String usuPwd = ""; // Clave
                    Collection col = DatabaseManager.getCollection(URI, usu, usuPwd);

                    System.out.println(" PRUEBA1.");

                    XPathQueryService servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
                    ResourceSet result = servicio.query("for $p in /productos/produc return $p");
                    ResourceIterator i; // se utiliza para recorrer un set de recursos
                    i = result.getIterator();
                    if (!i.hasMoreResources()) {
                            System.out.println(" LA CONSULTA NO DEVUELVE NADA.");
                    }
                    while (i.hasMoreResources()) {
                            Resource r = i.nextResource();
                            System.out.println("Elemento: " + (String) r.getContent());
                    }

            } catch (ClassNotFoundException ex) {
                    System.out.println(" ERROR EN EL DRIVER. COMPRUEBA CONECTORES.");
            } catch (InstantiationException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (IllegalAccessException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (XMLDBException ex) {
                    Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
            }

    }

    //Añadir 10 al stock
    public static void actualizaproductos() throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
            String driver = "org.exist.xmldb.DatabaseImpl"; // Driver para eXist
            try {
                    Class cl = Class.forName(driver); // Cargar del driver
                    Database database = (Database) cl.getDeclaredConstructor().newInstance(); // Instancia de la
                                                                                                                            // BD
                    DatabaseManager.registerDatabase(database); // Registro del driver

                    String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/BDProductosXML";
                    String usu = "admin"; // Usuario
                    String usuPwd = ""; // Clave
                    Collection col = DatabaseManager.getCollection(URI, usu, usuPwd);

                    XPathQueryService servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
                    String consulta = " for $p in collection('/db/ColeccionesXML/BDProductosXML')/productos/produc "
                                    + " let $st := $p/stock_actual " + " return update value $p/stock_actual " + " with $st+10 ";
                    ResourceSet result = servicio.query(consulta);
                    ResourceIterator i; // se utiliza para recorrer un set de recursos
                    i = result.getIterator();
                    if (!i.hasMoreResources()) {
                            System.out.println(" LA CONSULTA NO DEVUELVE NADA.");
                    }
                    while (i.hasMoreResources()) {
                            Resource r = i.nextResource();
                            System.out.println("Elemento: " + (String) r.getContent());
                    }

            } catch (ClassNotFoundException ex) {
                    System.out.println(" ERROR EN EL DRIVER. COMPRUEBA CONECTORES.");
            } catch (InstantiationException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (IllegalAccessException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (XMLDBException ex) {
                    Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
            }

    }

    public static void prueba2() throws TransformerConfigurationException, TransformerException, NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
            // Localizar un documento, extraerlo y guardarlo en disco
            String driver = "org.exist.xmldb.DatabaseImpl"; // Driver para eXist
            try {
                    Class cl = Class.forName(driver); // Cargar del driver
                    Database database = (Database) cl.getDeclaredConstructor().newInstance(); // Instancia de la
                                                                                                                            // BD
                    DatabaseManager.registerDatabase(database); // Registro del driver
                    String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/ColeccionPruebas";
                    String usu = "admin"; // Usuario
                    String usuPwd = ""; // Clave
                    Collection col = DatabaseManager.getCollection(URI, usu, usuPwd);
                    XMLResource res = (XMLResource) col.getResource("zonas.xml");
                    if (res == null) {
                            System.out.println("NO EXISTE EL DOCUMENTO");
                    } else {
                            System.out.println("ID del documento: " + res.getDocumentId());
                            // Volcado del documento a un arbol DOM
                            Node document = res.getContentAsDOM();
                            Source source = new DOMSource(document);
                            Transformer transformer = TransformerFactory.newInstance().newTransformer();
                            // Volcado del documento de memoria a consola
                            Result console = new StreamResult(System.out);
                            transformer.transform(source, console);
                            // Volcado del documento a un fichero
                            Result fichero = new StreamResult(new java.io.File("./zonas.xml"));
                            transformer = TransformerFactory.newInstance().newTransformer();
                            transformer.transform(source, fichero);
                    }
            } catch (ClassNotFoundException ex) {
                    System.out.println(" ERROR EN EL DRIVER. COMPRUEBA CONECTORES.");
            } catch (InstantiationException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (IllegalAccessException ex) {
                    System.out.println("Error al crear Instancia de la BD (Database) cl.newInstance()");
            } catch (XMLDBException ex) {
                    Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    //Para crear una nueva colección, se llama al método createCollection() del servicio CollectionManagementService.
    public static void crearcoleccysubirarchivo(String colecc) throws XMLDBException {
            String driver = "org.exist.xmldb.DatabaseImpl";
            Collection col = null;
            String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db";
            String usu = "admin";
            String usuPwd = "";
            try {
                    Class cl = Class.forName(driver);
                    Database database = (Database) cl.getDeclaredConstructor().newInstance();
                    DatabaseManager.registerDatabase(database);
                    col = DatabaseManager.getCollection(URI, usu, usuPwd);
                    if (col != null) {
                            // CREAR COLECCION dentro de col,
                            CollectionManagementService mgtService = (CollectionManagementService) col
                                            .getService("CollectionManagementService", "1.0");
                            mgtService.createCollection(colecc);
                            System.out.println(" *** COLECCION CREADA: " + colecc);
                    }
                    // Nos posicionamos en la nueva coleccion y añadimos el archivo
                    // Si es un ficheo binario ponemos BinaryResource
                    URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/ColeccionPruebas" + colecc;
                    col = DatabaseManager.getCollection(URI, usu, usuPwd);
                    File archivo = new File("NUEVAS_ZONAS.xml");
                    if (!archivo.canRead()) {
                            System.out.println("ERROR AL LEER EL FICHERO");
                    } else {
                            Resource nuevoRecurso = col.createResource(archivo.getName(), "XMLResource");
                            nuevoRecurso.setContent(archivo);
                            col.storeResource(nuevoRecurso);
                            System.out.println("FICHERO AÑADIDO");
                    }
            } catch (Exception e) {
                    System.out.println("Error al inicializar la BD eXist");
            }
    }

//
public static void borrarcoleccion(String colecc) throws XMLDBException {
    String driver = "org.exist.xmldb.DatabaseImpl";
    Collection col = null;
    String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db";
    String usu = "admin";
    String usuPwd = "";
    try {
            Class cl = Class.forName(driver);
            Database database = (Database) cl.getDeclaredConstructor().newInstance();
            DatabaseManager.registerDatabase(database);
            col = DatabaseManager.getCollection(URI, usu, usuPwd);
            CollectionManagementService mgtService = (CollectionManagementService) col
                            .getService("CollectionManagementService", "1.0");
            mgtService.removeCollection(colecc);
            System.out.println(" *** COLECCION BORRADA. ***");
    } catch (Exception e) {
            System.out.println("Error al inicializar la BD eXist");
    }
}

public static void borrarfichero(String colecc, String fichero) throws XMLDBException, NoSuchMethodException, InstantiationException, InstantiationException, IllegalAccessException, IllegalAccessException, InvocationTargetException, IllegalArgumentException, InvocationTargetException, IllegalArgumentException, InvocationTargetException, IllegalArgumentException, IllegalArgumentException {
    String driver = "org.exist.xmldb.DatabaseImpl";
    Collection col = null;
    String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/ColeccionPruebas/" + colecc;
    String usu = "admin";
    String usuPwd = "";
    try {
            Class cl = Class.forName(driver);
            Database database = null;
        try {
            database = (Database) cl.getDeclaredConstructor().newInstance();
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvocationTargetException ex) {
            Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
        }
            DatabaseManager.registerDatabase(database);
            col = DatabaseManager.getCollection(URI, usu, usuPwd);
            // borrar un xml de la colecci�n
            String ff = "'" + fichero + "'";
            Resource recursoParaBorrar = col.getResource(fichero);
            col.removeResource(recursoParaBorrar);
            System.out.println("FICHERO BORRADO.");
    } catch (NullPointerException e) {
            System.out.println("No se puede borrar. No se encuentra.");
    } catch (ClassNotFoundException ex) {
            System.out.println("ERROR DRIVER.");
    } catch (InstantiationException ex) {
            System.out.println("ERROR AL CREAR LA INSTANCIA.");
    } catch (IllegalAccessException ex) {
            System.out.println("ERROR AL CREAR LA INSTANCIA.");
    }
}

    //pág 310-311
    public static void ejecutarconsultafichero(String fichero) throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException {
        String driver = "org.exist.xmldb.DatabaseImpl"; // Driver para eXist
        try {
                Class cl = Class.forName(driver); // Cargar del driver
                Database database = null;
            try {
                database = (Database) cl.getDeclaredConstructor().newInstance(); // Instancia de la
            } catch (InvocationTargetException ex) {
                Logger.getLogger(Pruebas_XMLDB.class.getName()).log(Level.SEVERE, null, ex);
            }
                                                                                             // BD
                DatabaseManager.registerDatabase(database); // Registro del driver
                String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionesXML/BDProductosXML";
                String usu = "admin"; // Usuario
                String usuPwd = ""; // Clave
                Collection col = DatabaseManager.getCollection(URI, usu, usuPwd);
                System.out.println("Convirtiendo el fichero a cadena...");
                BufferedReader entrada = new BufferedReader(new FileReader(fichero));
                String linea = null;
                StringBuilder stringBuilder = new StringBuilder();
                String salto = System.getProperty("line.separator"); // es el salto

                while ((linea = entrada.readLine()) != null) {
                        stringBuilder.append(linea);
                        stringBuilder.append(salto);
                }
                String consulta = stringBuilder.toString();
                // Ejecutar consulta
                System.out.println("Consulta: " + consulta);
                XPathQueryService servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
                ResourceSet result = servicio.query(consulta);
                ResourceIterator i; // se utiliza para recorrer un set de recursos
                i = result.getIterator();
                if (!i.hasMoreResources()) {
                        System.out.println(" LA CONSULTA NO DEVUELVE NADA.");
                }
                while (i.hasMoreResources()) {
                        Resource r = i.nextResource();
                        System.out.println("Elemento: " + (String) r.getContent());
                }

        } catch (ClassNotFoundException ex) {
                System.out.println("ERROR EN EL DRIVER.");
        } catch (InstantiationException ex) {
                System.out.println("ERROR AL CREAR LA INSTANCIA.");
        } catch (IllegalAccessException ex) {
                System.out.println("ERROR AL CREAR LA INSTANCIA.");
        } catch (XMLDBException ex) {
                System.out.println("ERROR AL OPERAR CON EXIST.");
        } catch (FileNotFoundException ex) {
                System.out.println("El fichero no se localiza: " + fichero);
        } catch (IOException ex) {
                ex.printStackTrace();
        }
    }
}
