/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neodatis;

import NeoBiblio.Objetos.C_Libro;
import java.util.ArrayList;

/**
 *
 * @author mrnov
 */
public class Actor {
    private String id;
    private String name;
    private ArrayList<Movie> movies;

    public Actor() {
    }

    
    public Actor(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
