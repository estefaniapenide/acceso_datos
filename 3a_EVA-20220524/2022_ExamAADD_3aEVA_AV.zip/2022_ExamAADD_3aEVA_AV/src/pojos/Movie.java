/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojos;

import neodatis.*;
import java.util.ArrayList;

/**
 *
 * @author mrnov
 */
public class Movie {
    private String title;
    private Integer duration;
    private Writer writer;
    private Integer year;
    private String genre;
    private String synopsis;
    private ArrayList<Actor> actors;

    public Movie() {
    }

    
    public Movie(String title, Integer duration, Writer writer, Integer year,String genre,String synopsis) {
        this.title = title;
        this.duration = duration;
        this.writer = writer;
        this.year = year;
        this.genre = genre;
        this.synopsis = synopsis;
        this.actors = new ArrayList<Actor>();
    }
    
    public Movie(String title, Integer duration, Integer year,String genre,String synopsis) {
        this.title = title;
        this.duration = duration;
        this.year = year;
        this.genre = genre;
        this.synopsis = synopsis;
        this.actors = new ArrayList<Actor>();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Writer getWriter() {
        return writer;
    }

    public void setWriter(Writer writer) {
        this.writer = writer;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public ArrayList<Actor> getActors() {
        return actors;
    }

    public void setActors(ArrayList<Actor> actors) {
        this.actors = actors;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }
    
     public void vis(){
        System.out.println("\n\tID Writer: "+this.writer.getId()+"\n\tWriter Name: "+this.writer.getName()+"\n\tTitle: "+this.title+"\n\tGenre: "+this.genre+"\n\tDuration: "+this.duration+"\n\tYear: "+this.year);
    }
}
