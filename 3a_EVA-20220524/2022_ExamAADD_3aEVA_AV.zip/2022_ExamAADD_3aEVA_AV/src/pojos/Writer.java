/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojos;

import neodatis.*;
import NeoBiblio.Objetos.C_Libro;
import neodatis.*;
import java.util.ArrayList;

/**
 *
 * @author mrnov
 */
public class Writer {
    private String name;
    private String id;
    private ArrayList<Movie> movies;

    public Writer() {
    }

    public Writer(String id,String name) {
        this.id= id;
        this.name = name;
        this.movies=new ArrayList<Movie>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<Movie> getMovies() {
        return movies;
    }

    public void setMovies(ArrayList<Movie> movies) {
        this.movies = movies;
    }
    
    public void vis(){
            System.out.printf("%-20s %-50s %n",this.id,this.name);
        
    }
}
