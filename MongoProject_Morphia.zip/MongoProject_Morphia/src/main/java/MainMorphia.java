package morphia;


import ODM.bsontojson.Book;
import ODM.bsontojson.Publisher;
import ODM.modelo.*;
import com.mongodb.MongoClient;
import dev.morphia.Datastore;
import dev.morphia.Morphia;
import static dev.morphia.aggregation.Group.grouping;
import static dev.morphia.aggregation.Group.push;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;
import java.util.Iterator;
import java.util.List;
import org.bson.types.ObjectId;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mrnov
 */
public class MainMorphia {
    
    public static void main(String args[]){
        Morphia morphia = new Morphia();
        morphia.mapPackage("morphia");
        Datastore datastore = morphia.createDatastore(new MongoClient(), "MorphiaORM");
        datastore.ensureIndexes();
        
        Creacion(datastore);
    }
    
    public static void Creacion(Datastore datastore ){
        Publisher publisher = new Publisher(new ObjectId(), "Awsome Publisher");

        Book book = new Book("9781565927186", "Learning Java", "Tom Kirkman", 3.95, publisher);
        Book companionBook = new Book("9789332575103", "Java Performance Companion", 
          "Tom Kirkman", 1.95, publisher);

        book.addCompanionBooks(companionBook);

        datastore.save(companionBook);
        datastore.save(book);
        
        R_consulta (datastore,book);
    }
    
    public static void R_consulta(Datastore datastore, Book book){
        List<Book> books = datastore.createQuery(Book.class)
        .field("title")
        .contains("Learning Java")
        .find()
        .toList();

        System.out.println(books.size());
      //assertEquals(1, books.size());

      //assertEquals(book, books.get(0));
      System.out.println(books.get(0));
    }
    
    public static void U_modificacion(Datastore datastore, Book book){
        Query<Book> query = datastore.createQuery(Book.class)
        .field("title")
        .contains("Learning Java");

      UpdateOperations<Book> updates = datastore.createUpdateOperations(Book.class)
        .inc("price", 1);

      datastore.update(query, updates);

      List<Book> books = datastore.createQuery(Book.class)
        .field("title")
        .contains("Learning Java")
        .find()
        .toList();

      //assertEquals(4.95, books.get(0).getCost());
    }
    
    public static void D_borrado(Datastore datastore){
        Query<Book> query = datastore.createQuery(Book.class)
        .field("title")
        .contains("Learning Java");

      datastore.delete(query);

      List<Book> books = datastore.createQuery(Book.class)
        .field("title")
        .contains("Learning Java")
        .find()
        .toList();

        //assertEquals(0, books.size());
    }
    
    public static void agregacion (Datastore datastore){
        Iterator<Author> iterator = datastore.createAggregation(Book.class)
        .group("author", grouping("books", push("title")))
        .out(Author.class);
    }
    
    public static void proyeccion (Datastore datastore){
        List<Book> books = datastore.createQuery(Book.class)
        .field("title")
        .contains("Learning Java")
        .project("title", true)
        .find()
        .toList();

//        assertEquals("Learning Java", books.get(0).getTitle());
//        assertNull(books.get(0).getAuthor());
    }
}
