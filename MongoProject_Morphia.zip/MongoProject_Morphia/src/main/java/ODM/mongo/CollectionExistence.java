package ODM.mongo;

import java.util.ArrayList;

import org.bson.Document;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class CollectionExistence {

    private static MongoClient mongoClient;

    private static String testCollectionName;
    private static String databaseName;

    public static void setUp() {
        if (mongoClient == null) {
            mongoClient = new MongoClient("localhost", 27017);
        }
        databaseName = "MorphiaORM";
        testCollectionName = "student";
    }

    public static void collectionExistsSolution() {

        DB db = (DB)mongoClient.getDB(databaseName);

        System.out.println("collectionName " + testCollectionName +" exists? "+ db.collectionExists(testCollectionName));

    }

    public static void createCollectionSolution() {

        MongoDatabase database = mongoClient.getDatabase(databaseName);

        try {
            database.createCollection(testCollectionName);

        } catch (Exception exception) {
            System.err.println("Not Created. Collection already Exists");
        }

    }

    public static void listCollectionNamesSolution() {

        MongoDatabase database = mongoClient.getDatabase(databaseName);
        boolean collectionExists = database.listCollectionNames()
            .into(new ArrayList<String>())
            .contains(testCollectionName);

        System.out.println("collectionExists -> " + collectionExists);

    }

    public static void countSolution() {

        MongoDatabase database = mongoClient.getDatabase(databaseName);
        
        System.out.println("Colecciones num. "+database+ "-> "+database.listCollectionNames().toString());

        MongoCollection<Document> collection = database.getCollection(testCollectionName);

        System.out.println("Elementos/Documentos en la colección "+testCollectionName+" ->"+collection.countDocuments());

    }

    public static void main(String args[]) {

        //
        // Connect to cluster (default is localhost:27017)
        //
        setUp();

        //
        // Check the db existence using DB class's method
        //
        collectionExistsSolution();

        //
        // Check the db existence using the createCollection method of MongoDatabase class
        //
        createCollectionSolution();

        //
        // Check the db existence using the listCollectionNames method of MongoDatabase class
        //
        listCollectionNamesSolution();

        //
        // Check the db existence using the count method of MongoDatabase class
        //
        countSolution();

    }

}