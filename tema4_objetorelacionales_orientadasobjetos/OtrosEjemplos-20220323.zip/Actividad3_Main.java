/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mrnov
 */
import clases.Jugadores;
import clases.Paises;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.BigInteger;

import org.neodatis.odb.ODB;
import org.neodatis.odb.ODBFactory;
import org.neodatis.odb.ObjectValues;
import org.neodatis.odb.Objects;
import org.neodatis.odb.Values;

import org.neodatis.odb.core.query.IQuery;
import org.neodatis.odb.core.query.criteria.Where;

import org.neodatis.odb.core.query.criteria.ICriterion;

import org.neodatis.odb.core.query.criteria.And;
import org.neodatis.odb.core.query.criteria.Or;
import org.neodatis.odb.core.query.criteria.Not;

//import static org.neodatis.odb.core.query.criteria.Where.gt;

import org.neodatis.odb.impl.core.query.criteria.CriteriaQuery;
import org.neodatis.odb.impl.core.query.values.ValuesCriteriaQuery;
 

public class Actividad3_Main {
 
public static void main(String[] args) throws IOException {
    BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
    
    //(C) Read(UD)
    //verJugadoresPorPaisyDeporte("EEUU", "tenis");
    
    //jugadores14AnyosEspañaItaliaFrancia();
    
    //jugMayoresDe14();
    
   // jugDeMadridyEdadIgualoMayorA15();
   
    //  consultaItalia15anhos();

    consultaEdadMedia();
   
    //(CRU) Delete 
    borrarPaisdeBD("España");
    borrarJugador("Maria");
    
    //(CR)Update(D)  
    actualizarEdadJugadoresPorPais("España");
    cambiarDeporteJugador();
}

//apartado A)
/*Metodo que recibe el nombre de pais y un deporte y visualize los jugadores
que son de ese pais y practican ese deporte, si no hay ninguno da un mensaje*/
private static void verJugadoresPorPaisyDeporte(String pais, String deporte){
    ODB odb = ODBFactory.open("EQUIPOS.DB");
    
    ICriterion criterio = new And().add(Where.equal("pais.nombrePais", pais))
                                   .add(Where.equal("deporte", deporte));
    
    IQuery query = new CriteriaQuery(Jugadores.class, criterio);
    
    Objects jugadores = odb.getObjects(query);
    
    if (jugadores.size() == 0) {
        System.out.println ("No existen jugadores de "+pais+" no se pueden mostrar jugadores de "+deporte);
    } else {
        Jugadores jug;
        System.out.println("JUGADORES DE "+pais+" QUE JUEGAN AL "+deporte);
        while (jugadores.hasNext()) {
            jug = (Jugadores) jugadores.next();
            System.out.println("Nombre: "+jug.getNombre()+" Edad: "+ jug.getEdad()+", Pais: "+ jug.getPais().getNombrePais());
        }
    }
    odb.close();
}
 
//apartado B
/*Metodo que reciba un pais y lo borre de la BD Neodatis, comprueba si tiene
jugadores si tiene jugadores asigna null al pais de esos jugadores*/
private static void borrarPaisdeBD(String pais){
    ODB odb = ODBFactory.open("EQUIPOS.DB");
    IQuery query = new CriteriaQuery(Paises.class, Where.equal ("nombrePais", pais));
    Objects  objetosPais = odb.getObjects (query);
    //Obtiene solo el primer objeto Pais encontrado
    Paises paisABorrar = (Paises)objetosPais.getFirst();
    //Consulta para ver los jugadores con ese pais asignado
    IQuery query1 = new CriteriaQuery(Jugadores.class, Where.equal ("pais.nombrePais", pais));
    Objects  objetosJug = odb.getObjects (query1);
    if (objetosJug.size() == 0) {
        System.out.println("No existen jugadores de " + pais + " no se pueden mostrar jugadores de " + objetosJug);
    } else {
        Jugadores jug;
        System.out.println("JUGADORES DE " + pais);
    while (objetosJug.hasNext()) {
        jug = (Jugadores) objetosJug.next();
        Paises paisNuevo = null;
        System.out.println("Pais Anterior: " + jug.getPais().getNombrePais());
        jug.setPais(paisNuevo);
        odb.store(jug);
    }
        odb.commit();
    
    }
    //elimino el objeto Pais
    odb.delete(paisABorrar);
    
    odb.close();
}
//Metodo que devuelve los jugadores de 14 años de españa,italia y francia
private static void jugadores14AnyosEspañaItaliaFrancia() {
    ODB odb = ODBFactory.open("EQUIPOS.DB");
    ICriterion criterio = new And().add(Where.equal("edad", 14))
                                   .add(new Or().add(Where.equal("pais.nombrePais", "España"))
                                                .add(Where.equal("pais.nombrePais", "Italia"))
                                                .add(Where.equal("pais.nombrePais", "Francia")));

    IQuery query = new CriteriaQuery(Jugadores.class, criterio);
    Objects jugadores = odb.getObjects(query);
    if (jugadores.size() == 0) {
        System.out.println("No existen jugadores de 14 años de ESPAÑA, ITALIA, FRANCIA.");
    } else {
        Jugadores jug;
        System.out.println("Jugadores de 14 años de España, Italia, Francia.");
        while (jugadores.hasNext()) {
            jug = (Jugadores) jugadores.next();
            System.out.println("Nombre: " + jug.getNombre() + ",Edad: " + jug.getEdad() + ",Pais: " + jug.getPais().getNombrePais());
        }
    }
    odb.close();
}
//método recibe el nombre de un país y actualiza las edades de los jugadores de ese país.
//Suma 2 a la edad. Si no hay jugadores del país visualiza un mensaje indicándolo
private static void actualizarEdadJugadoresPorPais(String pais) {
    ODB odb = ODBFactory.open("EQUIPOS.DB");
    ICriterion criterio = Where.equal("pais.nombrePais", pais);
    IQuery query = new CriteriaQuery(Jugadores.class, criterio);
    Objects jugadores = odb.getObjects(query);
    if (jugadores.size() == 0) {
        System.out.println("No existen jugadores de" + pais + "no se actualiza la edad de " + pais);
    } else {
    Jugadores jug;
    System.out.println("ACTUALIZAMOS LA EDAD DE LOS JUGADORES DE " + pais);
    while (jugadores.hasNext()) {
        jug = (Jugadores) jugadores.next();
        int edad = jug.getEdad() + 2;
        System.out.println("Edad Anterior: " + jug.getNombre() + "Edad Anterior: " + jug.getEdad());
        jug.setEdad(edad);
        System.out.println("Edad Actualizada: " + jug.getNombre() + "Edad Actualizada: " + jug.getEdad());
        odb.store(jug);
    }
    odb.commit();
    }
    odb.close();
}
private static void cambiarDeporteJugador(){
    ODB odb = ODBFactory.open("EQUIPOS.DB");
    IQuery query = new CriteriaQuery(Jugadores.class, Where.equal ("nombre", "Maria"));
    Objects  objetos = odb.getObjects (query);
    //Obtiene solo el primer objeto encontrado
    Jugadores jug = (Jugadores) objetos.getFirst();
    //Cambia el deporte
    jug.setDeporte ("voley-playa");
    //Actualiza el objeto
    odb.store(jug);
    //Valida los cambios
    odb.commit();
    odb.close();
}
private static void borrarJugador(String nombre){
    ODB odb = ODBFactory.open("EQUIPOS.DB");
    IQuery query = new CriteriaQuery(Jugadores.class, Where.equal ("nombre", nombre));
    Objects  objetos = odb.getObjects(query);
    //Obtiene solo el primer objeto encontrado
    Jugadores jug = (Jugadores) objetos.getFirst();
    //elimina el objeto
    odb.delete(jug);
    odb.close();
}
private void obtenerJugCuyoNombreComienza(){
    ODB odb = ODBFactory.open("EQUIPOS.DB");
    ICriterion criterio = Where.like ("nombre", "M%");
    CriteriaQuery query = new CriteriaQuery(Jugadores.class, criterio);
    Objects jugadores = odb.getObjects(query);
    Jugadores jug;
    System.out.println("Jugadores que su nombre empieza por M");
    while (jugadores.hasNext()) {
    jug = (Jugadores) jugadores.next();
    System.out.println(jug.getNombre());
    }
    odb.commit();
    odb.close();
}
private static void jugMayoresDe14(){
    ODB odb = ODBFactory.open("EQUIPOS.DB");
    ICriterion criterio = Where.gt("edad", 14);
    CriteriaQuery query = new CriteriaQuery(Jugadores.class, criterio);
    Objects jugadores = odb.getObjects(query);
    Jugadores jug;
    System.out.println("Jugadores mayores de 14 años");
    while (jugadores.hasNext()) {
        jug = (Jugadores) jugadores.next();
        System.out.println(jug.getNombre());
    }
    odb.commit();
    odb.close();
}
private static void jugDeMadridyEdadIgualoMayorA15(){
    ODB odb = ODBFactory.open("EQUIPOS.DB");
    ICriterion criterio = new And().add(Where.equal("ciudad", "Madrid"))
                                    .add(Where.equal("edad", 15));
    CriteriaQuery query = new CriteriaQuery(Jugadores.class, criterio);
    Objects jugadores = odb.getObjects(query);
    Jugadores jug;
    System.out.println("Jugadores mayores de 15 años y que son de Madrid");
    while (jugadores.hasNext()) {
        jug = (Jugadores) jugadores.next();
        System.out.println(jug.getNombre());
    }
    
    odb.commit();
    odb.close();
}

private static void consultaItalia15anhos(){
   ODB odb = ODBFactory.open("EQUIPOS.DB");
   
   Values values = odb.getValues(new ValuesCriteriaQuery( Jugadores.class, new
                    And().add(Where.equal("pais.nombrePais", "Italia"))
                         .add(Where.equal("edad", 15)) )
                    .field("nombre")
                    .field("deporte")
                    );
     
    //opcion1
    while (values.hasNext()) {
                ObjectValues objectValues = (ObjectValues) values.next();
                System.out.printf("Nombre :  %s, Deporte : %s %n", objectValues.getByAlias("nombre"), objectValues.getByIndex(1));
    }
    
         //opcion2
    for(ObjectValues valor : values) {
        System.out.println(valor.toString());
        System.out.println(valor.getByAlias("nombre"));
     }
      
    
    ObjectValues jugadores = values.getFirst();
    //opcion3
    System.out.println("Jugadores de 15 años y que son Italia");
    for(int i=0;i<values.size();i ++) {
        ObjectValues objectValues = (ObjectValues) values.next();
          System.out.println(objectValues.getValues()[i]);
    }
      
    odb.close();
}

 private static void consultaEdadMedia() {
        ODB odb = ODBFactory.open("EQUIPOS.DB");
        Values val;
        ObjectValues ov;
        try {
                val = odb.getValues(new ValuesCriteriaQuery(Jugadores.class).avg("edad"));
                ov = val.nextValues();
                System.out.printf("AVG-La media de edad es: %f %n", ov.getByIndex(0));

        } catch (ArithmeticException e) {
                System.out.println(e.getMessage());

                Values val2 = odb.getValues(new ValuesCriteriaQuery(Jugadores.class).sum("edad").count("edad"));
                ObjectValues ov2 = val2.nextValues();
                float media;
                BigDecimal sumaedad = (BigDecimal) ov2.getByIndex(0);
                BigInteger cuenta = (BigInteger) ov2.getByIndex(1);
                media = sumaedad.floatValue() / cuenta.floatValue();

                System.out.printf("La media de edad es: %.2f Contador = %d  " + "suma = %.2f %n", media, cuenta, sumaedad);
        }

        odb.close();
    }//
}
